#include <stdio.h>
#include <string.h>
#include <va/va.h>

int main(int argc, char **argv)
{
    int attr = VAProfileHEVCMain;
    return 0;
}
