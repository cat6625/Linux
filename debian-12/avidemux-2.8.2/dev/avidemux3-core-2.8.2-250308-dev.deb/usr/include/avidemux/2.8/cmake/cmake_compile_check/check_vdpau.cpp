#include "vdpau/vdpau.h"
#include "vdpau/vdpau_x11.h"
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv)
{
    VdpPictureInfoMPEG4Part2 m4;
    return 0;
}
