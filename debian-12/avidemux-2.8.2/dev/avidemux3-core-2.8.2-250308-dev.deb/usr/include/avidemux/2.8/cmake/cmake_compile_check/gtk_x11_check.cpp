#include <gdk/gdkx.h>

int main(void)
{
    gdk_x11_lookup_xdisplay(NULL);

    return 0;
}
