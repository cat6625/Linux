

uint32_t      ADMVideo_interlaceCount( uint8_t *src ,uint32_t w, uint32_t h);
