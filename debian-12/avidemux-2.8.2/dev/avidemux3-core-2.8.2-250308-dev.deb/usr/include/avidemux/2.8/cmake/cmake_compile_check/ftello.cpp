#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    FILE *handle = NULL;
    uint64_t offset = ftello(handle);
    return 0;
}
