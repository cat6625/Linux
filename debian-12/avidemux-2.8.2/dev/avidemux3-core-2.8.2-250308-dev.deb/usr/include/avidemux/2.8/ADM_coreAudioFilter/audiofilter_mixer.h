/***************************************************************************
            \file audiofilter_mixer
            \brief Mixer
              (c) 2006 Mean , fixounet@free.fr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef AUDM_AUDIO_MIXER_H
#define AUDM_AUDIO_MIXER_H
#include "audiofilter_dolby.h"
class AUDMAudioFilterMixer : public AUDMAudioFilter
{
    protected:
        bool            bypass;
        uint32_t        input_channels;
        CHANNEL_CONF    _output;
        CHANNEL_CONF    _input;
        CHANNEL_TYPE    inputChannelMapping[MAX_CHANNELS];
        // output channel mapping
        CHANNEL_TYPE    outputChannelMapping[MAX_CHANNELS];
        // Dolby specific info
        // Surround Headphones
        float         * sHphDelay[8];
        int             sHphPos[8];
    public:
       ADMDolbyContext dolby;

      ~AUDMAudioFilterMixer();
      AUDMAudioFilterMixer(AUDMAudioFilter *instream,CHANNEL_CONF out);
      uint32_t   fill(uint32_t max,float *output,AUD_Status *status);
      // That filter changes its output channel mapping...
      virtual   CHANNEL_TYPE    *getChannelMapping(void );
      uint8_t  rewind(void)
                {
                        dolby.reset();
                        for (int k=0; k<8; k++)
                        {
                            for (int i=0; i<1024; i++)
                            {
                                sHphDelay[k][i] = 0.0;
                            }
                            sHphPos[k] = 0;
                        }                        
                        return AUDMAudioFilter::rewind();
                }
        float  getSHphSample(int sel, float in, float alpha, int delay);
};
#endif
