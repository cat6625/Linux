#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include <libintl.h>
int main(int argc, char **argv)
{
    char *foobar;
    foobar = gettext("test");
    return 0;
}
