#ifndef QT_SETTINGS_H
#define QT_SETTINGS_H
#include <QSettings>
#include "ADM_UIQT46_export.h"

ADM_UIQT46_EXPORT QSettings *qtSettingsCreate(void);

#endif
